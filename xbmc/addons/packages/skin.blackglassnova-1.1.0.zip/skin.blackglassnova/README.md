skin.blackglassnova
==========

Black Glass Nova skin for XBMC