This script can automaticly download all available artwork for your movies/tvshows in your library.
!!Each Movies and TV Show must have it's own subfolder!!

Eden 11.0:
    The script can now be downloaded from the official repo XBMC-repo (pre-Eden)
    This script requires an xbmc nightly build of September 21st or later


Skins using this Add-On in XBMC Eden 11.0:
    - See skin features wiki or skin support threads

----------------------------------------------------------------------------------------------
To run the script in bulk mode simply click on it in the 'Addons' or 'Programs' menu in XBMC.
You can change the settings if you wish in the addon settings page.

This script has some different run modes. Please check the XBMC wiki page:

http://wiki.xbmc.org/index.php?title=Add-on:Artwork_Downloader